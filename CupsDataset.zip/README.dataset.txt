# Cups > 2024-11-17 12:13am
https://universe.roboflow.com/david-szepvolgyi/cups-yz0fv

Provided by a Roboflow user
License: CC BY 4.0

