# Cups > 2024-11-17 5:23pm
https://universe.roboflow.com/david-szepvolgyi/cups-yz0fv

Provided by a Roboflow user
License: CC BY 4.0

